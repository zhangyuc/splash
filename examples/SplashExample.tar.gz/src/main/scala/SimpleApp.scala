import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import scala.util.Random
import splash.ParametrizedRDD
import splash.StreamProcessContext
import splash.ParameterSet

object SimpleApp {
  def main(args: Array[String]) {
    val filename = args(0)
    val learningRate = args(1).toDouble
    val numOfPartition = 16
    val numOfThread = 16
    
    println("Stochastic Gradient Descent")
    
    // Load data from file, convert the data format
    // such that every RDD entry takes the form:
    // (label, array of feature indices, array of feature values).
    // Then randomly split the RDD into 16 partitions.
    val sc = new SparkContext(new SparkConf())
    val data = sc.textFile(filename).map( line => {
      val tokens = line.split(" ")
      var y = tokens(0).toInt
      val x_key = new Array[Int](tokens.length-1)
      val x_value = new Array[Double](tokens.length-1)
      for(i <- 1 until tokens.length){
        val token_kv = tokens(i).split(":")
        x_key(i-1) = token_kv(0).toInt
        x_value(i-1) = token_kv(1).toDouble
      }
      (y,x_key,x_value)
    }).repartition(numOfPartition)
    
    // Get the total number of samples in the dataset
    val n = data.count()
    
    // Create parametrized RDD
    val paramRdd = new ParametrizedRDD(data)
    
    // Set learning rate
    paramRdd.foreachSharedVariable { sharedVar => sharedVar.set("learning.rate", learningRate) }
    
    // Set stream processing functions
    paramRdd.setProcessFunction(update)
    
    // Set loss function (optimal)
    paramRdd.setLossFunction(evaluateLoss)
    
    // Create stream processing context and
    // set the number of thread in parallel
    // stochastic algorithm to be 16
    var spc = (new StreamProcessContext).set("num.of.thread", numOfThread)
    
    for( i <- 0 until 100 ){
      // Take one pass over the dataset
      paramRdd.streamProcess(spc)
      
      // Evaluate the average loss
      val loss = paramRdd.map(evaluateLoss).reduce( _ + _ ) / n
      
      // Print: running time, average loss and the
      // selected sample weight
      println("Time = %5.3f; Loss = %5.8f; Selected Sample Weight = %f".format(paramRdd.getTotalTimeEllapsed, loss, paramRdd.getSelectedSampleWeight))
    }
  }
  
  //////////////////////////////////////////////////////////
  // Stream processing function for logistic regression
  // The arguments of the function are:
  // rnd -- random seed
  // entry -- one entry in the dataset; it takes the form (label, array of feature indices, array of feature values)
  // weight -- weight of the entry
  // sharedVar -- set of shared variables
  // localVar -- local variable associated with the entry
  //////////////////////////////////////////////////////////
  val update = (seed: Random, entry: (Int, Array[Int], Array[Double]), weight: Double, sharedVar : ParameterSet,  localVar: ParameterSet ) => {
    val y = entry._1
    val x_key = entry._2
    val x_value = entry._3
    
    val t = sharedVar.get("t")
    val learningRate = sharedVar.get("learning.rate")
    var sum = 0.0
    for(i <- 0 until x_key.length){
      // get the shared variable value by key "w:"+x_key(i)
      sum += sharedVar.get("w:"+x_key(i)) * x_value(i)
    }
    
    for(i <- 0 until x_key.length)
    {
      val delta = weight * learningRate / math.sqrt( t + 1 ) * y / (1.0 + math.exp(y*sum)) * x_value(i)
      // increase the shared variable by delta
      sharedVar.update("w:" + x_key(i), delta)
    }
    // increase the shared variable by weight
    sharedVar.update("t", weight)
  }
  
  //////////////////////////////////////////////////////////
  // Evaluating logistic loss for one sample
  //////////////////////////////////////////////////////////
  val evaluateLoss = (entry: (Int, Array[Int], Array[Double]), sharedVar : ParameterSet,  localVar: ParameterSet ) => {
    val y = entry._1
    val x_key = entry._2
    val x_value = entry._3
    
    var sum = 0.0
    for(i <- 0 until x_key.length){
      sum += sharedVar.get("w:" + x_key(i)) * x_value(i)
    }
    math.log( 1.0 + math.exp( - y * sum ) )
  }
}



