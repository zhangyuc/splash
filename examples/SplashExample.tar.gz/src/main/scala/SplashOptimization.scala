import org.apache.spark.{SparkConf,SparkContext}
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.mllib.classification.LogisticRegressionModel
import org.apache.spark.mllib.optimization.{LBFGS, LogisticGradient, SquaredL2Updater}

object SplashOptimization {
  def main(args: Array[String]) {
    val path = args(0)
    
    val sc = new SparkContext(new SparkConf())
    val data = MLUtils.loadLibSVMFile(sc, path)
    val numFeatures = data.take(1)(0).features.size
    
    // Split data into training (60%) and test (40%).
    val splits = data.randomSplit(Array(0.6, 0.4), seed = 11L)
    
    // Append 1 into the training data as intercept.
    val training = splits(0).map(x => (x.label, MLUtils.appendBias(x.features))).cache()
    val test = splits(1).cache()
    
    println("Splash Optimization Example")
    println(training.count() + " samples for training and " + test.count() + " samples for testing.")
    println("Feature dimension = " + numFeatures)
    
    // Train a logistic regression model using splash.optimization.StochasticGradientDescent
    val NumIterations = 10
    val initialWeightsWithIntercept = Vectors.dense(new Array[Double](numFeatures + 1))
    val weightsWithIntercept = (new splash.optimization.StochasticGradientDescent())
      .setGradient(new splash.optimization.LogisticGradient())
      .setNumIterations(NumIterations)
      .optimize(training, initialWeightsWithIntercept)
    
    val model = new LogisticRegressionModel(
      Vectors.dense(weightsWithIntercept.toArray.slice(0, weightsWithIntercept.size - 1)),
      weightsWithIntercept(weightsWithIntercept.size - 1))
    
    // Clear the default threshold.
    model.clearThreshold()
    
    // Compute raw scores on the test set.
    val scoreAndLabels = test.map { point =>
      val score = model.predict(point.features)
      (score, point.label)
    }
    
    // Get evaluation metrics.
    val metrics = new BinaryClassificationMetrics(scoreAndLabels)
    val auROC = metrics.areaUnderROC()
    
    println("Area under ROC = " + auROC)
  }
}