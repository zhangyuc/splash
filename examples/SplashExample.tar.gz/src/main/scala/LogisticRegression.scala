import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import splash._

object LogisticRegression {
  def main(args: Array[String]) {
    val filename = args(0)
    val learningRate = args(1).toDouble
    
    // Load data from file, every RDD element takes this form:
    // (label, array of feature indices, array of feature values).
    val sc = new SparkContext(new SparkConf())
    val data = sc.textFile(filename).map( line => {
      val tokens = line.split(" ")
      var y = tokens(0).toInt
      
      val x_key = new Array[Int](tokens.length-1)
      val x_value = new Array[Double](tokens.length-1)
      var norm = 0.0
      for(i <- 1 until tokens.length){
        val token_kv = tokens(i).split(":")
        x_key(i-1) = token_kv(0).toInt
        x_value(i-1) = token_kv(1).toDouble
        norm += x_value(i-1) * x_value(i-1)
      }
      
      // normalize the feature vector
      for(i <- 0 until x_value.length){
        x_value(i) = x_value(i) / math.sqrt(norm)
      }
      (y,x_key,x_value)
    })
    
    // Get the total number of samples in the dataset
    val n = data.count()
    
    println("Stochastic Gradient Descent")
    println("Dataset contains " + n + " data points.")
    
    // Create parametrized RDD
    val paramRdd = new ParametrizedRDD(data)
    
    // Set learning rate
    paramRdd.foreachSharedVariable { sharedVar => sharedVar.set("learning.rate", learningRate) }
    
    // Set stream processing functions
    paramRdd.setProcessFunction(process)
    
    // Set loss function (optional)
    // paramRdd.setLossFunction(evaluateLoss)
    
    // Create stream processing context
    val spc = new StreamProcessContext()
    
    for( i <- 0 until 100 ){
      // Take one pass over the dataset
      paramRdd.run(spc)
      
      // Evaluate the average loss
      val loss = paramRdd.map(evaluateLoss).reduce( _ + _ ) / n
      
      // Print: running time, average loss and the selected element weight
      println("Time = %5.3f; Loss = %5.8f; Group Number = %d".format(paramRdd.getTotalTimeEllapsed, loss, paramRdd.getProposedGroupNum.toInt))
    }
  }
  
  //////////////////////////////////////////////////////////
  // Stream processing function for logistic regression
  // The arguments of the function are:
  // rnd -- random seed
  // element -- one element in the dataset; it takes the form (label, array of feature indices, array of feature values)
  // weight -- weight of the element
  // sharedVar -- set of shared variables
  // localVar -- local variable associated with the element
  //////////////////////////////////////////////////////////
  val process = (element: (Int, Array[Int], Array[Double]), weight: Double, sharedVar : SharedVariableSet,  localVar: LocalVariableSet) => {
    val y = element._1
    val x_key = element._2
    val x_value = element._3
    
    val t = sharedVar.get("t")
    val learningRate = sharedVar.get("learning.rate")
    var sum = 0.0
    for(i <- 0 until x_key.length){
      // get the shared variable value by key "w:"+x_key(i)
      sum += sharedVar.get("w:"+x_key(i)) * x_value(i)
    }
    
    for(i <- 0 until x_key.length)
    {
      val delta = weight * learningRate / math.sqrt( t + 1 ) * y / (1.0 + math.exp(y*sum)) * x_value(i)
      // increase the shared variable by delta
      sharedVar.add("w:" + x_key(i), delta)
    }
    // increase the shared variable by weight
    sharedVar.add("t", weight)
  }
  
  //////////////////////////////////////////////////////////
  // Evaluating logistic loss for one sample
  //////////////////////////////////////////////////////////
  val evaluateLoss = (element: (Int, Array[Int], Array[Double]), sharedVar : SharedVariableSet,  localVar: LocalVariableSet ) => {
    val y = element._1
    val x_key = element._2
    val x_value = element._3
    
    var sum = 0.0
    for(i <- 0 until x_key.length){
      sum += sharedVar.get("w:" + x_key(i)) * x_value(i)
    }
    math.log( 1.0 + math.exp( - y * sum ) )
  }
}
