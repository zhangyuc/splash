import org.apache.spark.{SparkConf,SparkContext}
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.mllib.linalg.{SparseVector}
import org.apache.spark.mllib.regression.LabeledPoint
import splash.core.{SplashConf,ParametrizedRDD,SharedVariableSet,LocalVariableSet}

object LogisticRegression {
  def main(args: Array[String]) {
    val path = args(0)
    val learningRate = 20
    val NumIteration = 20
    val regParam = 1e-6
    
    // Load data from file
    val sc = new SparkContext(new SparkConf())
    val data = MLUtils.loadLibSVMFile(sc, path).repartition(sc.defaultParallelism).cache()
    val n = data.count()
    val dimension = data.first().features.size
    
    println("Logistic Regression Example")
    println("Dataset contains " + n + " data points.")
    println("Feature dimension = " + dimension)
    
    // Create parametrized RDD and declare shared array
    val paramRdd = new ParametrizedRDD(data)
    paramRdd.foreachSharedVariable( sharedVar => {
      sharedVar.declareArray("w", dimension)
      sharedVar.set("learningRate", learningRate)
      sharedVar.set("regParam", regParam)
    })
    
    // Set stream processing functions
    paramRdd.setProcessFunction(process)
    
    // Set loss function (optional)
    // paramRdd.setLossFunction(evaluateLoss)
    
    // Create stream processing context
    val spc = new SplashConf()
    
    for( i <- 0 until NumIteration ){
      // Take one pass over the dataset
      paramRdd.run(spc)
      
      // Evaluate the average loss
      val loss = paramRdd.map(evaluateLoss).reduce( _ + _ ) / n
      
      // Print: running time, average loss and the thread number
      println("Time = %5.3f; Loss = %5.8f; Thread Number = %d".format(paramRdd.getTotalTimeEllapsed, loss, paramRdd.getLastIterationThreadNumber))
    }
  }
  
  // data processing function for logistic regression
  val process = (elem: LabeledPoint, weight: Double, sharedVar : SharedVariableSet,  localVar: LocalVariableSet) => {
    val label = elem.label
    val features = elem.features.asInstanceOf[SparseVector]
    val xIndices = features.indices
    val xValues = features.values
    val n = xIndices.length
    
    sharedVar.add("t", weight)
    val t = sharedVar.get("t")
    val learningRate = sharedVar.get("learningRate")
    val regParam = sharedVar.get("regParam")
    
    // get weight vector w
    val w = sharedVar.getArrayElements("w", xIndices)
    
    // compute the inner product x * w
    var innerProduct = 0.0
    for(i <- 0 until n){
      innerProduct += xValues(i) * w(i)
    }
    val margin = - 1.0 * innerProduct
    val multiplier = (1.0 / (1.0 + math.exp(margin))) - label
    
    // compute the update
    val delta = new Array[Double](n)
    val stepsize = weight * learningRate / math.sqrt(t)
    for(i <- 0 until n){
      delta(i) = - stepsize * multiplier * xValues(i)
    }
    
    // update the weight vector
    sharedVar.multiplyArray("w", 1 - stepsize * regParam)
    sharedVar.addArrayElements("w", xIndices, delta)
  }
  
  // Evaluating logistic loss for one sample
  val evaluateLoss = (elem: LabeledPoint, sharedVar : SharedVariableSet,  localVar: LocalVariableSet ) => {
    val label = elem.label
    val features = elem.features.asInstanceOf[SparseVector]
    val xIndices = features.indices
    val xValues = features.values
    val n = xIndices.length
    
    // get weight vector w
    val w = sharedVar.getArrayElements("w", xIndices)
    
    // compute the inner product x * w
    var innerProduct = 0.0
    for(i <- 0 until n){
      innerProduct += xValues(i) * w(i)
    }
    val margin = -1.0 * innerProduct
    if (label > 0) {
      log1pExp(margin)
    } else {
      log1pExp(margin) - margin
    }
  }
  
  val log1pExp = (x: Double) => {
    if (x > 0) {
      x + math.log1p(math.exp(-x))
    } else {
      math.log1p(math.exp(x))
    }
  }
}
